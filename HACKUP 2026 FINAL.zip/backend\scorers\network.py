import pickle
import numpy as np
from core.config import MODELS_DIR

class NetworkScorer:
    def __init__(self, model_path=MODELS_DIR / "network_ids.pkl"):
        self.model_path = str(model_path)
        self.model = None
        self.feature_names = []
        self._load_model()

    def _load_model(self):
        try:
            with open(self.model_path, "rb") as f:
                self.model = pickle.load(f)
                self.feature_names = pickle.load(f)
                print(f"✅ Loaded Network IDS Model from {self.model_path}")
        except Exception as e:
            print(f"⚠️ Model mapping failed for {self.model_path}: {e}. Heuristic fallback active.")
            self.model = None


    def score_request(self, metadata):
        """
        Infers risk score using metadata and trained RFC.
        """
        # Elite Inference Logic
        if self.model and self.feature_names:
            # Construct feature vector based on saved feature names
            # If feature missing in metadata, default to 0
            vector = [metadata.get(feat, 0) for feat in self.feature_names]
            # Inference (Probability of Bot: 1)
            score = float(self.model.predict_proba([vector])[0][1])
            return score


        # Elite Heuristic Fallback
        score = 0.0
        
        # 1. VPN/Proxy Logic (Immediate High Risk)
        if metadata.get('is_proxy', False):
            score += 0.4
            
        # 2. Geo-Shift (Speed-of-light violation)
        if metadata.get('geo_shift', False):
            score += 0.5
            
        # 3. Flow Regularity (Bot Signatures)
        # Bots often have very regular patterns (Low IAT STD)
        iat_std = metadata.get('iat_std', 100)
        if iat_std < 5 and iat_std > 0:
            score += 0.3
            
        # 4. Request Rate (Burstiness)
        if metadata.get('req_per_minute', 0) > 100:
            score += 0.4

        return min(score, 1.0)
