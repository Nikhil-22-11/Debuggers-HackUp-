from sklearn.ensemble import IsolationForest
import numpy as np
import pandas as pd

class AnomalyScorer:
    """
    Unsupervised detection of 'Low-and-Slow' and unknown attack patterns.
    Uses Isolation Forest to identify outliers in the multi-dimensional session data.
    """
    def __init__(self):
        # We start with a pre-tuned configuration for session-based anomaly detection
        self.model = IsolationForest(
            n_estimators=100,
            contamination=0.01, # Assume 1% of traffic is malicious/anomaly
            random_state=42
        )
        self.history = []
        self.is_trained = False

    def train_on_batch(self, data_batch):
        """
        Receives a batch of session features: [ [v1, v2, v3, ...], ... ]
        Fits the model incrementally if needed, though IsolationForest is typically fit in batch.
        """
        df = pd.DataFrame(data_batch)
        self.model.fit(df)
        self.is_trained = True
        print(f"Anomaly Detection Model trained on {len(df)} samples.")

    def score_session(self, features):
        """
        Input: [f1, f2, f3, ...]
        Returns: 0.0 (Normal) to 1.0 (Anomaly)
        """
        if not self.is_trained:
            # If not yet trained, everything is 'unknown' (mid-risk)
            return 0.5
            
        # Standardize input for the model
        X = np.array([features])
        
        # Isolation Forest returns -1 for anomaly and 1 for normal
        decision = self.model.decision_function(X)
        
        # Convert decision function to 0-1 scale
        # -1 -> 1.0 (Max Anomaly), 1 -> 0.0 (Min Anomaly)
        score = 1.0 - (decision[0] + 0.5) # Approximate normalized mapping
        
        return max(min(score, 1.0), 0.0)
