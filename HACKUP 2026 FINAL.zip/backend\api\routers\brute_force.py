"""
Brute Force Protection Router
Handles:
  - Logging each attempt (email + masked password) to the database
  - Creating/checking persistent account lockouts (survives page refresh)
  - Broadcasting alerts to the dashboard WebSocket
  - Querying the full brute force log for the admin view
"""
from fastapi import APIRouter, Request
from datetime import datetime, timedelta
import json
import uuid

from db.database import SessionLocal, BruteForceAttempt, AccountLockout, SecurityAlert, BlockedIP, CaptchaLog, CaptchaVerified
from schemas import BruteForceAttemptRequest, LockoutCheckRequest, CaptchaLogRequest, CaptchaVerifyRequest
from api.routers.websockets import broadcast_alert
from core import state

router = APIRouter(tags=["Brute Force Protection"])

LOCKOUT_DURATION_SECONDS = 60
MAX_ATTEMPTS = 3


def _mask_password(password: str) -> str:
    """Masks password for safe storage — first 2 chars + asterisks."""
    if len(password) <= 2:
        return "**"
    return password[:2] + "*" * (len(password) - 2)


@router.post("/api/v1/brute-force/attempt")
async def log_brute_force_attempt(data: BruteForceAttemptRequest, request: Request):
    """
    Frontend calls this on every failed login attempt.
    Stores the email + masked password, increments counter.
    If attempt_number reaches MAX_ATTEMPTS → creates a lockout record.
    """
    client_ip = request.headers.get("X-Forwarded-For", request.client.host).split(",")[0].strip()
    if data.ip_address and data.ip_address != "unknown":
        client_ip = data.ip_address  # Allow frontend to pass its detected IP

    masked_pw = _mask_password(data.password_raw)

    db = SessionLocal()
    try:
        # 1. Log the attempt
        attempt = BruteForceAttempt(
            email=data.email,
            password_mask=masked_pw,
            ip_address=client_ip,
            attempt_number=data.attempt_number,
            session_id=data.session_id,
        )
        db.add(attempt)

        # 2. Also log to security_alerts for the main dashboard feed
        db.add(SecurityAlert(
            alert_type="BRUTE_FORCE_ATTEMPT",
            ip_address=client_ip,
            score=round(data.attempt_number / MAX_ATTEMPTS, 2),
            action=f"ATTEMPT_{data.attempt_number}_OF_{MAX_ATTEMPTS}",
            analysis=json.dumps([
                f"Email targeted: {data.email}",
                f"Password pattern: {masked_pw}",
                f"Attempt #{data.attempt_number} in session {data.session_id}"
            ])
        ))

        state.TOTAL_REQUESTS += 1
        state.ANOMALY_SESSIONS += 1

        # 3. If max attempts reached → create lockout record
        response = {"status": "logged", "attempt": data.attempt_number, "lockout": False}

        if data.attempt_number >= MAX_ATTEMPTS:
            unlock_time = datetime.utcnow() + timedelta(seconds=LOCKOUT_DURATION_SECONDS)

            # Upsert lockout: remove old record if exists, create fresh one
            existing = db.query(AccountLockout).filter(AccountLockout.email == data.email).first()
            if existing:
                existing.locked_at = datetime.utcnow()
                existing.unlocks_at = unlock_time
                existing.is_active = True
                existing.ip_address = client_ip
                existing.total_attempts = data.attempt_number
            else:
                db.add(AccountLockout(
                    email=data.email,
                    ip_address=client_ip,
                    unlocks_at=unlock_time,
                    is_active=True,
                    total_attempts=data.attempt_number,
                ))

            state.TRUE_POSITIVES += 1

            response["lockout"] = True
            response["unlocks_at"] = unlock_time.isoformat()
            response["seconds_remaining"] = LOCKOUT_DURATION_SECONDS

            # Broadcast immediate alert to dashboard
            await broadcast_alert({
                "type": "BRUTE_FORCE_LOCKOUT",
                "score": 1.0,
                "ip": client_ip,
                "action": "ACCOUNT_LOCKOUT_60S",
                "analysis": [
                    f"HARD LOCKOUT: {data.email}",
                    f"3 failed attempts intercepted",
                    f"Credentials harvested: {masked_pw} (masked)",
                    f"Account locked for {LOCKOUT_DURATION_SECONDS}s"
                ]
            })

        db.commit()
    finally:
        db.close()

    return response


@router.post("/api/v1/brute-force/check-lockout")
async def check_lockout_status(data: LockoutCheckRequest):
    """
    Frontend calls this on page load / refresh to check if an email is still locked.
    Returns remaining seconds if locked, 0 if free.
    This is what makes the lockout persist across page refreshes.
    """
    db = SessionLocal()
    try:
        lockout = db.query(AccountLockout).filter(
            AccountLockout.email == data.email,
            AccountLockout.is_active == True
        ).first()

        if not lockout:
            return {"locked": False, "seconds_remaining": 0, "email": data.email}

        now = datetime.utcnow()
        remaining = (lockout.unlocks_at - now).total_seconds()

        if remaining <= 0:
            # Auto-expire: mark as inactive
            lockout.is_active = False
            db.commit()
            return {"locked": False, "seconds_remaining": 0, "email": data.email}

        return {
            "locked": True,
            "seconds_remaining": int(remaining),
            "email": data.email,
            "locked_at": lockout.locked_at.isoformat(),
            "unlocks_at": lockout.unlocks_at.isoformat(),
        }
    finally:
        db.close()


@router.post("/api/v1/brute-force/captcha")
async def log_captcha_challenge(data: CaptchaLogRequest):
    """Logs a CAPTCHA challenge presented to a suspicious user. Defaults to BOT."""
    db = SessionLocal()
    try:
        masked_pw = _mask_password(data.password_raw)
        captcha_log = CaptchaLog(
            email=data.email,
            password_mask=masked_pw,
            captcha_code=data.captcha_code,
            status="BOT"
        )
        db.add(captcha_log)
        db.commit()
        db.refresh(captcha_log)
        return {"status": "logged", "captcha_id": captcha_log.id}
    finally:
        db.close()


@router.put("/api/v1/brute-force/captcha/verify")
async def verify_captcha_challenge(data: CaptchaVerifyRequest):
    """Marks a previously logged CAPTCHA challenge as solved and moves it to a separate database table."""
    db = SessionLocal()
    try:
        captcha_log = db.query(CaptchaLog).filter(CaptchaLog.id == data.id).first()
        if captcha_log:
            captcha_log.status = "HUMAN"
            
            # --- MOVE TO SEPARATE DATABASE TABLE ---
            verified_entry = CaptchaVerified(
                email=captcha_log.email,
                password_mask=captcha_log.password_mask,
                captcha_code=captcha_log.captcha_code,
                status="HUMAN"
            )
            db.add(verified_entry)
            db.commit()
            return {"status": "verified"}
        return {"status": "not_found"}
    finally:
        db.close()


@router.get("/api/v1/brute-force/attempts")
async def get_all_attempts():
    """Admin view: returns all logged brute force attempts ordered by most recent."""
    db = SessionLocal()
    try:
        attempts = db.query(BruteForceAttempt).order_by(
            BruteForceAttempt.attempted_at.desc()
        ).limit(100).all()

        lockouts = db.query(AccountLockout).order_by(
            AccountLockout.locked_at.desc()
        ).limit(50).all()
        
        captchas = db.query(CaptchaLog).order_by(
            CaptchaLog.created_at.desc()
        ).limit(50).all()
        
        verified_humans = db.query(CaptchaVerified).order_by(
            CaptchaVerified.verified_at.desc()
        ).limit(50).all()

        def format_dt(val):
            if not val:
                return None
            try:
                # 1. Ensure we have a string to parse
                dt_str = val if isinstance(val, str) else str(val)
                # 2. Parse the base record (Assuming UTC from server)
                # SQLite strings format: 'YYYY-MM-DD HH:MM:SS.mmmmmm'
                # We strip the microseconds if they cause parsing issues
                base_dt = datetime.strptime(dt_str.split(".")[0], "%Y-%m-%d %H:%M:%S")
                # 3. Apply IST Offset (+5:30)
                ist_dt = base_dt + timedelta(hours=5, minutes=30)
                # 4. Return formatted IST string
                return ist_dt.strftime("%Y-%m-%d %I:%M:%S %p")
            except Exception as e:
                return str(val) # Fallback to raw if logic fails

        return {
            "total_attempts": len(attempts),
            "attempts": [
                {
                    "id": a.id,
                    "email": a.email,
                    "password_mask": a.password_mask,
                    "ip": a.ip_address,
                    "attempt_number": a.attempt_number,
                    "session_id": a.session_id,
                    "time": format_dt(a.attempted_at)
                }
                for a in attempts
            ],
            "lockouts": [
                {
                    "id": l.id,
                    "email": l.email,
                    "ip": l.ip_address,
                    "locked_at": format_dt(l.locked_at),
                    "unlocks_at": format_dt(l.unlocks_at),
                    "is_active": l.is_active,
                    "total_attempts": l.total_attempts
                }
                for l in lockouts
            ],
            "captchas": [
                {
                    "id": c.id,
                    "email": c.email,
                    "password_mask": c.password_mask,
                    "captcha_code": c.captcha_code,
                    "status": c.status,
                    "time": format_dt(c.created_at if hasattr(c, 'created_at') else c.verified_at)
                }
                for c in (list(captchas) + list(verified_humans))
            ]
        }
    finally:
        db.close()
