'use client'

import React, { useState, useEffect, useMemo } from 'react'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Activity, ShieldCheck, AlertCircle, Zap, ShieldAlert, Cpu } from 'lucide-react'
import { FilterState } from '@/app/page'

interface VelocityPoint {
  time: string
  human: number
  anomalous: number
}

export default function TrafficVelocityAnalysis({ filters, isUnderAttack }: { filters: FilterState, isUnderAttack: boolean }) {
  const [data, setData] = useState<VelocityPoint[]>([])
  const [metrics, setMetrics] = useState({
    throughput: 118.6,
    mitigation: 88.9,
    humanReqs: 1414,
    anomalousReqs: 63,
    accuracy: 99.8
  })

  // Initialize data stream
  useEffect(() => {
    const initialData = Array.from({ length: 60 }, (_, i) => ({
      time: i.toString(),
      human: 1400 + Math.random() * 150,
      anomalous: 30 + Math.random() * 30
    }))
    setData(initialData)
  }, [])

  // Real-time updates with Aggressive Attack Dynamics
  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => {
        const nextPoint = {
          time: (prev.length + 1).toString(),
          // BATTLE LOGIC: When under attack, human traffic is squeezed/suppressed
          human: isUnderAttack 
            ? 250 + Math.random() * 150 // CRATER TO THE FLOOR
            : 1400 + Math.random() * 150, // NORMAL
          // BATTLE LOGIC: Anomalous traffic explodes past the human baseline
          anomalous: isUnderAttack 
            ? 1600 + Math.random() * 400 // EXPLODE TO THE CEILING (1.6k+)
            : 30 + Math.random() * 30 // NOMINAL
        }
        return [...prev.slice(1), nextPoint]
      })

      setMetrics({
        throughput: isUnderAttack ? 180 + Math.random() * 40 : 110 + Math.random() * 20,
        mitigation: isUnderAttack ? 72 + Math.random() * 8 : 99.2 + Math.random() * 0.5,
        humanReqs: isUnderAttack ? 240 + Math.floor(Math.random() * 100) : 1400 + Math.floor(Math.random() * 100),
        anomalousReqs: isUnderAttack ? 1800 + Math.floor(Math.random() * 500) : 60 + Math.floor(Math.random() * 10),
        accuracy: isUnderAttack ? 97.4 + Math.random() * 1.5 : 99.8 + Math.random() * 0.1
      })
    }, 1000) // FASTER UPDATE FOR BETTER FEEDBACK
    return () => clearInterval(interval)
  }, [isUnderAttack])

  return (
    <div className="w-full space-y-10">
      <Card className="relative overflow-hidden border-none shadow-3xl bg-white dark:bg-slate-900/40 rounded-[3rem] transition-all duration-1000">
        
        {/* TOP HEADER HUD */}
        <CardHeader className="flex flex-row items-start justify-between px-12 pt-12 pb-6">
            <div className="flex flex-col">
                <div className="flex items-center gap-3">
                   <CardTitle className="text-3xl font-black italic tracking-tighter uppercase text-slate-800 dark:text-white leading-none">Traffic Velocity Analysis</CardTitle>
                   <div className="w-3 h-3 rounded-full bg-emerald-500/20 flex items-center justify-center">
                      <div className={`w-1.5 h-1.5 rounded-full ${isUnderAttack ? 'bg-red-500 shadow-[0_0_8px_#ef4444]' : 'bg-emerald-500'} animate-pulse`} />
                   </div>
                </div>
                <span className="text-[10px] font-black text-slate-300 dark:text-slate-600 uppercase tracking-[0.4em] mt-3 leading-none italic font-mono">LIVE INSTITUTIONAL INTELLIGENCE FEED</span>
            </div>
            
            <div className="flex items-center gap-12 pt-1">
                <div className="flex flex-col items-end">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">THROUGHPUT</span>
                    <div className="flex items-baseline gap-1">
                        <span className={`text-2xl font-black tracking-tighter italic ${isUnderAttack ? 'text-red-500' : 'text-blue-600'}`}>{metrics.throughput.toFixed(1)}k</span>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter italic">req/s</span>
                    </div>
                </div>
                <div className="flex flex-col items-end">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">MITIGATION</span>
                    <span className={`text-2xl font-black tracking-tighter italic ${isUnderAttack ? 'text-red-500' : 'text-emerald-500'}`}>{metrics.mitigation.toFixed(1)}%</span>
                </div>
            </div>
        </CardHeader>

        <CardContent className="px-10 pb-10">
          <div className="h-[420px] w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHuman" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.08}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorThreat" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                <XAxis dataKey="time" hide />
                <YAxis anchor={0} tick={{ fontSize: 11, fontWeight: '700', fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v/1000).toFixed(1)}k`} domain={[0, 2200]} />
                <Tooltip content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                        return (
                        <div className="bg-white/95 dark:bg-slate-900 border border-slate-100 dark:border-white/5 p-4 rounded-2xl shadow-3xl backdrop-blur-xl">
                            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Velocity_Node</span>
                            <div className="space-y-1">
                                <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-blue-600" /><span className="text-xs font-black text-slate-900 dark:text-white uppercase">HUMAN: {payload[0].value?.toLocaleString()}</span></div>
                                <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-red-500" /><span className="text-xs font-black text-red-500 uppercase">THREAT: {payload[1].value?.toLocaleString()}</span></div>
                            </div>
                        </div>
                        )
                    }
                    return null
                }} />
                <Area type="monotone" dataKey="human" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorHuman)" animationDuration={0} isAnimationActive={false} />
                <Area type="monotone" dataKey="anomalous" stroke="#ef4444" strokeWidth={3} fillOpacity={1} fill={isUnderAttack ? "url(#colorThreat)" : "transparent"} animationDuration={0} isAnimationActive={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* HUD FOOTER METRICS GRID */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 bg-slate-50/50 dark:bg-slate-950/40 p-8 rounded-[2.5rem] border border-slate-100 dark:border-white/5">
             
             <div className="flex flex-col space-y-3 px-2">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">VERIFIED HUMAN</span>
                <div className="flex items-baseline gap-2">
                    <span className={`text-3xl font-black tracking-tighter italic leading-none transition-all ${isUnderAttack ? 'text-slate-400 scale-75' : 'text-blue-600'}`}>{metrics.humanReqs.toLocaleString()}</span>
                    <span className="text-[11px] font-black text-slate-400 uppercase tracking-tighter italic">REQS/S</span>
                </div>
             </div>

             <div className="flex flex-col space-y-3 border-l border-slate-200 dark:border-white/5 px-8">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">ANOMALOUS LOAD</span>
                <div className="flex items-baseline gap-2">
                    <span className={`text-3xl font-black tracking-tighter italic leading-none transition-all ${isUnderAttack ? 'text-red-500 scale-125' : 'text-slate-400'}`}>{metrics.anomalousReqs.toLocaleString()}</span>
                    <span className="text-[11px] font-black text-slate-400 uppercase tracking-tighter italic">REQS/S</span>
                </div>
             </div>

             <div className="flex flex-col space-y-3 border-l border-slate-200 dark:border-white/5 px-8">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">DEFLECTION ACCURACY</span>
                <div className="flex items-baseline gap-2">
                    <span className={`text-3xl font-black tracking-tighter italic leading-none ${isUnderAttack ? 'text-amber-500' : 'text-emerald-500'}`}>{metrics.accuracy.toFixed(1)}</span>
                    <span className="text-[11px] font-black text-slate-400 uppercase tracking-tighter italic">%</span>
                </div>
             </div>

          </div>
        </CardContent>
      </Card>
    </div>
  )
}
