import requests
import os

class SOCAlerts:
    """
    Elite SOC Alerting Utility: Physically notifies security analysts via Telegram.
    Can be used for Out-of-Band (OOB) threat notification.
    """
    def __init__(self, token=None, chat_id=None):
        # Placeholders - Should be moved to environment variables for production
        self.token = token or "your_token_here"
        self.chat_id = chat_id or "your_chat_id_here"
        self.is_enabled = bool(token and chat_id)

    def send_alert(self, alert_data):
        """Sends a formatted alert to a Telegram channel."""
        if not self.is_enabled:
            print(f"📡 [SIMULATED SOC ALERT]: {alert_data['type']} for {alert_data.get('ip', 'Unknown')}")
            return False

        message = (
            f"🛡️ *FinShield SOC ALERT*\n"
            f"⚠️ *Type:* {alert_data['type']}\n"
            f"🎯 *IP:* `{alert_data.get('ip', 'N/A')}`\n"
            f"📊 *Score:* {alert_data.get('score', 'N/A')}\n"
            f"🛠️ *Action:* {alert_data.get('action', 'Blocked')}\n"
            f"📝 *Analysis:* {', '.join(alert_data.get('analysis', []))}"
        )

        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        try:
            r = requests.post(url, data={"chat_id": self.chat_id, "text": message, "parse_mode": "Markdown"})
            return r.status_code == 200
        except Exception as e:
            print(f"❌ SOC Alerting Error: {e}")
            return False
