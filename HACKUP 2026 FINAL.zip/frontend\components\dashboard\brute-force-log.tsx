'use client'

import { useState, useEffect, useCallback } from 'react'
import { LockKeyhole, Mail, Eye, EyeOff, Clock, Shield, RefreshCw, AlertTriangle, CheckCircle2, XCircle, Database, Wifi } from 'lucide-react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

interface BruteAttempt {
  id: number
  email: string
  password_mask: string
  ip: string
  attempt_number: number
  session_id: string
  time: string
}

interface Lockout {
  id: number
  email: string
  ip: string
  locked_at: string
  unlocks_at: string
  is_active: boolean
  total_attempts: number
}

interface CaptchaLog {
  id: number
  email: string
  password_mask: string
  captcha_code: string
  status: string
  time: string
}

interface BruteForceData {
  total_attempts: number
  attempts: BruteAttempt[]
  lockouts: Lockout[]
  captchas: CaptchaLog[]
}

// Group attempts by session_id
function groupBySession(attempts: BruteAttempt[]) {
  const groups: Record<string, BruteAttempt[]> = {}
  for (const a of attempts) {
    if (!groups[a.session_id]) groups[a.session_id] = []
    groups[a.session_id].push(a)
  }
  return Object.entries(groups).sort((a, b) => {
    const tA = new Date(a[1][0].time).getTime()
    const tB = new Date(b[1][0].time).getTime()
    return tB - tA
  })
}

function timeAgo(iso: string) {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000)
  if (diff < 60) return `${diff}s ago`
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  return `${Math.floor(diff / 3600)}h ago`
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

function RemainingTimer({ unlocks_at }: { unlocks_at: string }) {
  const [remaining, setRemaining] = useState(() =>
    Math.max(0, Math.floor((new Date(unlocks_at).getTime() - Date.now()) / 1000))
  )
  useEffect(() => {
    if (remaining <= 0) return
    const t = setInterval(() => setRemaining(p => (p <= 1 ? 0 : p - 1)), 1000)
    return () => clearInterval(t)
  }, [unlocks_at])
  return <span className={`font-mono font-black text-sm ${remaining > 0 ? 'text-red-500' : 'text-emerald-500'}`}>{remaining > 0 ? `${remaining}s remaining` : 'EXPIRED'}</span>
}

export default function BruteForceLog() {
  const [data, setData] = useState<BruteForceData | null>(null)
  const [loading, setLoading] = useState(true)
  const [showPasswords, setShowPasswords] = useState(false)
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date())

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(`${API_URL}/api/v1/brute-force/attempts`)
      const json = await res.json()
      setData(json)
      setLastRefresh(new Date())
    } catch (e) {
      console.error('Failed to fetch brute force log', e)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 8000)
    return () => clearInterval(interval)
  }, [fetchData])

  const sessions = data ? groupBySession(data.attempts) : []
  const activeLockouts = data?.lockouts.filter(l => l.is_active) ?? []
  const totalLockouts = data?.lockouts.length ?? 0

  return (
    <div className="space-y-14 animate-in fade-in duration-500">

      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-4">
            <div className="w-2.5 h-8 bg-red-600 rounded-full shadow-[0_0_15px_#dc2626]" />
            <h2 className="text-3xl font-black tracking-tighter uppercase leading-none italic text-slate-900 dark:text-white">Brute Force Security Log</h2>
          </div>
          <span className="text-[11px] font-black uppercase text-slate-400 tracking-[0.4em] ml-6">Live DB — Last refreshed {formatTime(lastRefresh.toISOString())}</span>
        </div>
        <button
          onClick={fetchData}
          disabled={loading}
          className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-black text-xs uppercase tracking-widest shadow hover:shadow-md transition-all active:scale-95"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-500' : ''}`} />
          Refresh
        </button>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Attempts', value: data?.total_attempts ?? '—', icon: LockKeyhole, color: 'red' },
          { label: 'Unique Sessions', value: sessions.length, icon: Wifi, color: 'orange' },
          { label: 'Active Lockouts', value: activeLockouts.length, icon: Shield, color: activeLockouts.length > 0 ? 'red' : 'emerald' },
          { label: 'Total Lockouts', value: totalLockouts, icon: Database, color: 'blue' },
        ].map(kpi => {
          const Icon = kpi.icon
          const colors: Record<string, string> = { red: 'text-red-600 bg-red-50', orange: 'text-orange-600 bg-orange-50', emerald: 'text-emerald-600 bg-emerald-50', blue: 'text-blue-600 bg-blue-50' }
          return (
            <div key={kpi.label} className="bg-white dark:bg-slate-900/60 rounded-[2.5rem] p-8 shadow-lg border-none flex flex-col gap-4">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${colors[kpi.color]}`}>
                <Icon className={`w-5 h-5 ${kpi.color === 'red' ? 'text-red-600' : kpi.color === 'orange' ? 'text-orange-600' : kpi.color === 'emerald' ? 'text-emerald-600' : 'text-blue-600'}`} />
              </div>
              <div className="flex flex-col gap-1">
                <span className={`text-4xl font-black tracking-tighter italic ${kpi.color === 'red' ? 'text-red-600' : kpi.color === 'orange' ? 'text-orange-600' : kpi.color === 'emerald' ? 'text-emerald-600' : 'text-blue-600'}`}>{kpi.value}</span>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">{kpi.label}</span>
              </div>
            </div>
          )
        })}
      </div>

      {/* Active Lockouts Panel */}
      {activeLockouts.length > 0 && (
        <div className="bg-red-50 dark:bg-red-950/20 border-2 border-red-200 dark:border-red-900/40 rounded-[3rem] p-10 shadow-lg">
          <div className="flex items-center gap-4 mb-8">
            <div className="p-3 bg-red-600 rounded-2xl"><AlertTriangle className="w-5 h-5 text-white" /></div>
            <div>
              <h3 className="text-xl font-black uppercase tracking-tight text-red-700 dark:text-red-400">Active Account Lockouts</h3>
              <p className="text-[10px] font-black text-red-400 uppercase tracking-[0.3em] mt-1">Access denied for these email accounts</p>
            </div>
          </div>
          <div className="space-y-4">
            {activeLockouts.map(lockout => (
              <div key={lockout.id} className="bg-white dark:bg-slate-900 rounded-[1.8rem] p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4 shadow border border-red-100 dark:border-red-900/30">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-xl"><LockKeyhole className="w-4 h-4 text-red-600" /></div>
                  <div className="flex flex-col gap-1">
                    <span className="font-black text-sm text-slate-800 dark:text-white">{lockout.email}</span>
                    <span className="font-mono text-[10px] text-slate-400">{lockout.ip}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <RemainingTimer unlocks_at={lockout.unlocks_at} />
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{lockout.total_attempts} attempts · locked {timeAgo(lockout.locked_at)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Attempt Log by Session */}
      <div className="bg-white dark:bg-slate-900/60 rounded-[3rem] shadow-xl overflow-hidden">
        <div className="px-10 py-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-black uppercase tracking-tight text-slate-900 dark:text-white">Credential Attempt Log</h3>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-1">Grouped by attack session · Password values masked</p>
          </div>
          <button
            onClick={() => setShowPasswords(!showPasswords)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
          >
            {showPasswords ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            {showPasswords ? 'Hide Masks' : 'Show Masks'}
          </button>
        </div>

        {sessions.length === 0 ? (
          <div className="px-10 py-20 text-center">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-4 opacity-50" />
            <p className="text-slate-400 font-black uppercase tracking-widest text-sm">No brute force attempts recorded</p>
            <p className="text-slate-300 text-xs mt-2">Trigger a Brute Force Burst from the login cockpit to generate data</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-50 dark:divide-slate-800">
            {sessions.map(([sessionId, attempts]) => {
              const hadLockout = data?.lockouts.some(l => attempts.some(a => a.email === l.email)) ?? false
              const email = attempts[0].email
              const ip = attempts[0].ip
              const firstTime = attempts[attempts.length - 1].time
              const lastTime = attempts[0].time
              return (
                <div key={sessionId} className="px-10 py-8 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                  {/* Session Header */}
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
                    <div className="flex items-center gap-3">
                      <div className={`w-2.5 h-2.5 rounded-full ${hadLockout ? 'bg-red-500 shadow-[0_0_8px_#ef4444]' : 'bg-orange-400'}`} />
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          <span className="font-black text-sm text-slate-800 dark:text-white">{email}</span>
                          {hadLockout && <span className="px-2 py-0.5 bg-red-100 dark:bg-red-900/30 text-red-600 text-[9px] font-black uppercase rounded-lg tracking-wider">LOCKED</span>}
                        </div>
                        <span className="font-mono text-[10px] text-slate-400 mt-0.5">{ip}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{attempts.length} attempt{attempts.length > 1 ? 's' : ''}</span>
                      <span className="font-mono text-[9px] text-slate-400">{timeAgo(firstTime)}</span>
                    </div>
                  </div>

                  {/* Individual Attempts Table */}
                  <div className="space-y-2 ml-5">
                    {[...attempts].reverse().map((a) => (
                      <div key={a.id} className={`flex items-center gap-4 px-5 py-3 rounded-2xl ${a.attempt_number === 3 ? 'bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/20' : 'bg-slate-50 dark:bg-slate-800/30'}`}>
                        {/* Attempt number badge */}
                        <span className={`text-[10px] font-black w-8 h-8 flex-shrink-0 rounded-full flex items-center justify-center ${a.attempt_number === 3 ? 'bg-red-600 text-white' : a.attempt_number === 2 ? 'bg-orange-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                          #{a.attempt_number}
                        </span>
                        {/* Email */}
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <span className="text-xs text-slate-600 dark:text-slate-300 font-mono truncate">{a.email}</span>
                        </div>
                        {/* Password mask */}
                        {showPasswords && (
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <LockKeyhole className="w-3 h-3 text-slate-300" />
                            <span className="font-mono text-[11px] text-red-500 font-black tracking-widest">{a.password_mask}</span>
                          </div>
                        )}
                        {/* Time */}
                        <span className="font-mono text-[10px] text-slate-400 flex-shrink-0">{formatTime(a.time)}</span>
                        {/* Status */}
                        {a.attempt_number === 3
                          ? <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                          : <AlertTriangle className="w-4 h-4 text-orange-400 flex-shrink-0" />}
                      </div>
                    ))}
                  </div>

                  {/* Session ID */}
                  <div className="mt-4 ml-5">
                    <span className="font-mono text-[9px] text-slate-300 uppercase tracking-widest">Session: {sessionId}</span>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* All Lockout History */}
      {(data?.lockouts.length ?? 0) > 0 && (
        <div className="bg-white dark:bg-slate-900/60 rounded-[3rem] shadow-xl overflow-hidden">
          <div className="px-10 py-8 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-xl font-black uppercase tracking-tight text-slate-900 dark:text-white">Lockout History</h3>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-1">All account lockout records from database</p>
          </div>
          <div className="divide-y divide-slate-50 dark:divide-slate-800">
            {data?.lockouts.map(l => (
              <div key={l.id} className="px-10 py-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-xl ${l.is_active ? 'bg-red-100 dark:bg-red-900/30' : 'bg-slate-100 dark:bg-slate-800'}`}>
                    {l.is_active ? <LockKeyhole className="w-4 h-4 text-red-600" /> : <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="font-black text-sm text-slate-800 dark:text-white">{l.email}</span>
                    <span className="font-mono text-[10px] text-slate-400">{l.ip}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-[11px] font-black uppercase tracking-widest px-3 py-1 rounded-lg ${l.is_active ? 'bg-red-100 text-red-600' : 'bg-emerald-50 text-emerald-600'}`}>
                    {l.is_active ? 'ACTIVE' : 'EXPIRED'}
                  </span>
                  {l.is_active && <RemainingTimer unlocks_at={l.unlocks_at} />}
                  <span className="font-mono text-[9px] text-slate-400">Locked: {formatTime(l.locked_at)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* CAPTCHA Challenge Log */}
      {(data?.captchas.length ?? 0) > 0 && (
        <div className="bg-white dark:bg-slate-900/60 rounded-[3rem] shadow-xl overflow-hidden mt-8">
          <div className="px-10 py-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="text-xl font-black uppercase tracking-tight text-slate-900 dark:text-white">Neural Captcha Tracking</h3>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-1">Bot identity verification challenges</p>
            </div>
            <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-2xl">
              <Shield className="w-5 h-5 text-purple-600" />
            </div>
          </div>
          <div className="divide-y divide-slate-50 dark:divide-slate-800">
            {data?.captchas.map(c => (
              <div key={c.id} className="px-10 py-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-xl border ${c.status === 'BOT' ? 'bg-slate-100 dark:bg-slate-800 border-slate-200' : 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200'}`}>
                    <AlertTriangle className={`w-4 h-4 ${c.status === 'BOT' ? 'text-slate-500' : 'text-emerald-500'}`} />
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="font-black text-sm text-slate-800 dark:text-white">{c.email}</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] text-red-500 font-bold">{showPasswords ? c.password_mask : '********'}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-8">
                  <div className="flex flex-col items-center">
                    <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">CHALLENGE</span>
                    <span className="font-mono text-lg font-black tracking-widest text-blue-500">{c.captcha_code}</span>
                  </div>
                  <div className="flex flex-col items-end gap-1 min-w-[100px]">
                    <span className={`text-[11px] font-black uppercase tracking-widest px-3 py-1 rounded-lg ${c.status === 'BOT' ? 'bg-orange-100 text-orange-600' : 'bg-emerald-100 text-emerald-600'}`}>
                      {c.status}
                    </span>
                    <span className="font-mono text-[9px] text-slate-400">{formatTime(c.time)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
