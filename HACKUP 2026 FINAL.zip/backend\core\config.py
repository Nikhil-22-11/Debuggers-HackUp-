import os
from pathlib import Path

# Base directory (backend/)
BASE_DIR = Path(__file__).resolve().parent.parent

# Project root directory
ROOT_DIR = BASE_DIR.parent

# Models directory
MODELS_DIR = ROOT_DIR / "models"

# Database path
DATABASE_URL = f"sqlite:///{BASE_DIR}/finshield.db"

# API Configuration
ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "https://localhost:3000",
    "https://127.0.0.1:3000"
]
