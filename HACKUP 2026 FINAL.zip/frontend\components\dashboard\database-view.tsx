'use client'

import { useState, useEffect } from 'react'
import { Database, ShieldAlert, Activity, RefreshCw } from 'lucide-react'

interface DatabaseRecord {
  id: number
  ip: string
  reason: string
  time: string
}

interface DatabaseResponse {
  table: string
  records: DatabaseRecord[]
}

export default function DatabaseView() {
  const [data, setData] = useState<DatabaseResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date())

  const fetchData = async () => {
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'
      const response = await fetch(`${apiUrl}/api/v1/admin/database`)
      const result = await response.json()
      setData(result)
      setLastRefreshed(new Date())
    } catch (error) {
      console.error("Failed to fetch database records:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Database className="w-6 h-6 text-blue-600" />
            Live Threat Database
          </h2>
          <p className="text-sm text-gray-500 mt-1">
            Real-time tabular view of the SQLite backend database (finshield.db).
            <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full animate-pulse">
              Syncing Live
            </span>
          </p>
        </div>
        <button
          onClick={() => { setLoading(true); fetchData(); }}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg shadow-sm hover:bg-gray-50 transition-colors text-sm font-medium text-gray-700"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Force Refresh
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="p-4 bg-gray-50 border-b border-gray-100 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-500" />
            <h3 className="font-semibold text-gray-700">Blocked IPs Registry</h3>
          </div>
          <div className="text-xs text-gray-500 flex items-center gap-1">
            <Activity className="w-3 h-3" />
            Last updated: {lastRefreshed.toLocaleTimeString()}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b">
              <tr>
                <th scope="col" className="px-6 py-4">ID</th>
                <th scope="col" className="px-6 py-4">IP Address</th>
                <th scope="col" className="px-6 py-4 w-1/2">Threat Reason</th>
                <th scope="col" className="px-6 py-4">Timestamp (IST)</th>
              </tr>
            </thead>
            <tbody>
              {loading && !data ? (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-gray-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-blue-500" />
                    Querying SQLite Database...
                  </td>
                </tr>
              ) : data?.records && data.records.length > 0 ? (
                data.records.map((record) => (
                  <tr key={record.id} className="bg-white border-b hover:bg-red-50/30 transition-colors">
                    <td className="px-6 py-4 font-medium text-gray-900">#{record.id}</td>
                    <td className="px-6 py-4">
                      <span className="bg-red-100 text-red-800 text-xs font-mono px-2 py-1 rounded">
                        {record.ip}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-700 font-medium">{record.reason}</td>
                    <td className="px-6 py-4 font-mono text-xs text-gray-900 font-bold">
                      {new Date(record.time.includes('Z') || record.time.includes('+') ? record.time : record.time + 'Z').toLocaleString('en-IN', { 
                        timeZone: 'Asia/Kolkata',
                        hour: '2-digit', 
                        minute: '2-digit', 
                        second: '2-digit',
                        hour12: true 
                      })}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                    No threats logged in the database yet. Run the attack simulator!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
