import '../styles/globals.css'
import { Inter } from 'next/font/google'
import { Toaster } from "@/components/ui/toaster"
import { BiometricsProvider } from '@/hooks/use-biometrics-engine'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'FinShield AI | Autonomous Security Command Center',
  description: 'Enterprise-grade biometric AI security and real-time threat interdiction.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="light">
      <body className={inter.className}>
        <BiometricsProvider>
          {children}
          <Toaster />
        </BiometricsProvider>
      </body>
    </html>
  )
}
