from pydantic import BaseModel
from typing import List, Optional

class TelemetryData(BaseModel):
    username: Optional[str] = "anonymous"
    mouse_events: List[dict] = []
    keyboard_events: List[dict] = []
    network_metadata: dict = {}

class TelemetryBulk(BaseModel):
    session_id: str
    events: List[dict]  # {type: 'mouse'|'keyboard', data: {...}, timestamp: float}

class LoginRequest(BaseModel):
    username: str
    password: str
    telemetry: TelemetryData

class TransactionData(BaseModel):
    amount: float
    type: str = "TRANSFER"
    oldbalanceOrg: float = 0.0
    newbalanceOrig: float = 0.0
    oldbalanceDest: float = 0.0
    newbalanceDest: float = 0.0
    network_metadata: dict = {}

# --- Brute Force Tracking ---

class BruteForceAttemptRequest(BaseModel):
    """Sent from the frontend on each failed login attempt."""
    email: str
    password_raw: str       # We'll mask this server-side, never stored as-is
    session_id: str
    attempt_number: int     # 1, 2, or 3
    ip_address: Optional[str] = "unknown"

class LockoutCheckRequest(BaseModel):
    """Frontend asks the backend if an email is currently locked out."""
    email: str

class CaptchaLogRequest(BaseModel):
    """Frontend logs a generated CAPTCHA challenge."""
    email: str
    password_raw: str
    captcha_code: str

class CaptchaVerifyRequest(BaseModel):
    """Frontend marks a CAPTCHA as solved."""
    id: int
