from fastapi import APIRouter, HTTPException, Request
import logging
from core import state
from schemas import LoginRequest
from db.database import SessionLocal, BlockedIP
from scorers.behavioral import BehavioralScorer
from scorers.network import NetworkScorer
from scorers.risk_engine import RiskEngine
from utils.enrichment import IPEnricher
from utils.soc_alerts import SOCAlerts
import os

router = APIRouter(tags=["FinShield AI"])

# Initialize Engines
behavioral_engine = BehavioralScorer()
network_engine = NetworkScorer() 
risk_engine = RiskEngine()
enricher = IPEnricher()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "8634566130:AAFcqZPJn-hstpyuxvgBD0jdkaAcN3PD594")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "5424247358")
soc_alerts = SOCAlerts(token=TELEGRAM_TOKEN, chat_id=TELEGRAM_CHAT_ID)


@router.post("/auth/login")
async def login(http_request: Request, request: LoginRequest):
    """
    Elite Level Login validation with Multi-Weighted Risk Scoring.
    """
    state.TOTAL_REQUESTS += 1
    
    # 1. IP Enrichment & Profile context
    client_ip = http_request.headers.get("X-Forwarded-For", request.telemetry.network_metadata.get('ip', '127.0.0.1')).split(",")[0].strip()
    metadata = enricher.get_metadata(client_ip)
    
    db = SessionLocal()
    is_blocked = db.query(BlockedIP).filter(BlockedIP.ip_address == client_ip).first()
    db.close()
    if is_blocked:
        raise HTTPException(status_code=403, detail="Security Block: High-Risk IP.")

    # 2. Score Behavioral Biometrics
    mouse_score = behavioral_engine.score_mouse_movement(request.telemetry.mouse_events)
    keyboard_score = behavioral_engine.score_keystrokes(request.telemetry.keyboard_events)
    b_score = (mouse_score * 0.7) + (keyboard_score * 0.3)
    
    # 3. Score Network/Infrastructure metrics
    n_score = network_engine.score_request(request.telemetry.network_metadata)
    if metadata["is_datacenter"]: n_score = max(n_score, 0.9) # Immediate red flag for botnets
    
    # 4. Score Session Context (Velocity/History)
    s_score = 0.1 # Placeholder for session historical data
    
    # 5. Total Risk Calculation (Elite Weighted Engine)
    total_risk, analysis = risk_engine.calculate_total_score(b_score, n_score, s_score)
    risk_level = risk_engine.get_risk_level(total_risk)

    # 6. Real-Time Mitigation Actions
    if total_risk > 0.85:
        db = SessionLocal()
        if not db.query(BlockedIP).filter(BlockedIP.ip_address == client_ip).first():
            db.add(BlockedIP(ip_address=client_ip, reason="Critical AI Risk Score Threshold Exceeded"))
            db.commit()
        db.close()
        
        alert_data = {
            "type": "CRITICAL_THREAT",
            "score": f"{total_risk*100:.1f}%",
            "level": risk_level,
            "ip": client_ip,
            "action": "IP_HARD_BLOCK",
            "analysis": analysis
        }
        from api.routers.websockets import broadcast_alert
        await broadcast_alert(alert_data)
        soc_alerts.send_alert(alert_data) 
        
        raise HTTPException(status_code=403, detail="Anomaly Detected. Threat Neutralized.")
    
    return {
        "status": "success",
        "risk": total_risk,
        "analysis": analysis,
        "category": risk_level,
        "enrichment": metadata
    }
