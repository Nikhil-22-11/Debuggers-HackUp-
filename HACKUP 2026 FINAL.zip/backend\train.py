import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import pickle
import os

class EliteTrainer:
    """
    Elite-level trainer for the FinShield Security Stack.
    Processes:
    1. Network IDS (CIC-IDS-2018)
    2. Keystroke Biometrics (DSL Dynamics)
    3. Transaction Fraud (Credit Card)
    """

    def train_network_ids(self, file_path):
        print(f"--- Training Network IDS (CIC-IDS-2018) from {file_path} ---")
        # Reading only first N rows to avoid memory overflow in hackathon environment
        df = pd.read_csv(file_path, low_memory=False, nrows=100000)

        
        # Mapping labels to binary (0: Benign, 1: Attack)
        if 'Label' in df.columns:
            df['target'] = df['Label'].apply(lambda x: 0 if str(x).lower() == 'benign' else 1)
        else:
            print("Error: 'Label' column not found.")
            return

        # Selecting core features (Flow Duration, Packets, etc.)
        # Converting all to numeric and dropping NaNs
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if 'target' in numeric_cols: numeric_cols.remove('target')
        
        # Handling NaN and Infinity (common in network flow data)
        X = df[numeric_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
        y = df['target']

        
        self._fit_and_save(X, y, "models/network_ids.pkl")

    def train_keystroke_biometrics(self, file_path):
        print(f"--- Training Keystroke Biometrics (DSL) from {file_path} ---")
        df = pd.read_csv(file_path)
        
        # Features are columns 3 to end (numeric dwell/interval times)
        X = df.iloc[:, 3:]
        # Mapping subject to binary (for demo: subject 's002' is 0 (authorized), others are 1 (unauthorized))
        y = df['subject'].apply(lambda x: 0 if x == 's002' else 1)
        
        self._fit_and_save(X, y, "models/keystroke_model.pkl")

    def train_transaction_fraud(self, file_path):
        print(f"--- Training Transaction Fraud (Credit Card) from {file_path} ---")
        df = pd.read_csv(file_path)
        
        # V1-V28 are PCA features, Amount is raw
        X = df.drop(['Class', 'Time'], axis=1)
        y = df['Class']
        
        self._fit_and_save(X, y, "models/transaction_fraud.pkl")

    def _fit_and_save(self, X, y, save_path):
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        clf = RandomForestClassifier(n_estimators=50, max_depth=10, n_jobs=-1)
        clf.fit(X_train, y_train)
        
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        with open(save_path, "wb") as f:
            pickle.dump(clf, f)
            # Saving feature names for inference alignment
            pickle.dump(list(X.columns), f)
        
        print(f"✅ Model saved to {save_path} (Accuracy: {clf.score(X_test, y_test):.4f})")

if __name__ == "__main__":
    trainer = EliteTrainer()
    
    # Executing training on discovered datasets
    try:
        trainer.train_network_ids("data/archive (2)/02-14-2018.csv")
        trainer.train_keystroke_biometrics("data/archive (1)/DSL-StrongPasswordData.csv")
        trainer.train_transaction_fraud("data/archive/creditcard.csv")
    except Exception as e:
        print(f"❌ Training Error: {e}")
