from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import json
from core import state
from db.database import SessionLocal, SecurityAlert

router = APIRouter()

@router.websocket("/ws/alerts")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    state.WEBSOCKETS.append(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        state.WEBSOCKETS.remove(websocket)

async def broadcast_alert(alert_data):
    """Pushes real-time security alerts to the dashboard and logs to SQLite."""
    raw_score = alert_data.get("score", 0)
    if isinstance(raw_score, str):
        try:
            parsed_score = float(raw_score.strip('%')) / 100
        except ValueError:
            parsed_score = 0.0
    else:
        parsed_score = float(raw_score)

    db = SessionLocal()
    new_alert = SecurityAlert(
        alert_type=alert_data.get("type"),
        ip_address=alert_data.get("ip", "Unknown"),
        score=parsed_score,
        action=alert_data.get("action"),
        analysis=json.dumps(alert_data.get("analysis", []))
    )
    db.add(new_alert)
    db.commit()
    db.close()

    for ws in state.WEBSOCKETS:
        try:
            await ws.send_text(json.dumps(alert_data))
        except:
            pass
