from fastapi import APIRouter
from core import state
from schemas import TelemetryBulk, TransactionData
from api.routers.websockets import broadcast_alert

router = APIRouter(tags=["FinShield AI"])

@router.post("/api/telemetry")
async def ingest_telemetry(data: TelemetryBulk):
    if data.session_id not in state.SESSIONS:
        state.SESSIONS[data.session_id] = {"mouse": [], "keyboard": [], "risk_score": 0.0}
    
    for event in data.events:
        if event['type'] == 'mouse':
            state.SESSIONS[data.session_id]["mouse"].append(event['data'])
        elif event['type'] == 'keyboard':
            state.SESSIONS[data.session_id]["keyboard"].append(event['data'])
            
    return {"status": "received", "events_processed": len(data.events)}

@router.post("/security/transaction")
async def check_transaction(data: TransactionData):
    state.TOTAL_REQUESTS += 1
    
    fraud_score = 0.1
    if data.amount > 100000: fraud_score = 0.95 

    if fraud_score > 0.8:
        state.ANOMALY_SESSIONS += 1
        await broadcast_alert({
            "type": "TRANSACTION_FRAUD",
            "amount": data.amount,
            "score": fraud_score,
            "action": "TRANSACTION_FLAGGED",
            "reason": "High-Value Anomaly Pattern"
        })
        return {"status": "flagged", "score": fraud_score, "action": "BLOCK"}
    
    return {"status": "approved", "score": fraud_score}
