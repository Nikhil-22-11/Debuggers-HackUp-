import requests
import json
import time

# FinShield AI: Bot Attack Simulator
# This script sends perfectly mechanical (robotic) telemetry to the backend.

def run_test():
    # 1. Simulate PERFECT (Robotic) mouse movements (Straight line, no jitter)
    bot_mouse = [{"x": i, "y": 100, "t": int(time.time() * 1000) + i*10} for i in range(0, 100, 10)]

    # 2. Simulate PERFECT (Robotic) keystrokes (exactly 100ms apart)
    bot_keyboard = [
        {"key": "a", "type": "keydown", "t": 1000}, {"key": "a", "type": "keyup", "t": 1100},
        {"key": "d", "type": "keydown", "t": 1200}, {"key": "d", "type": "keyup", "t": 1300},
        {"key": "m", "type": "keydown", "t": 1400}, {"key": "m", "type": "keyup", "t": 1500},
        {"key": "i", "type": "keydown", "t": 1600}, {"key": "i", "type": "keyup", "t": 1700},
        {"key": "n", "type": "keydown", "t": 1800}, {"key": "n", "type": "keyup", "t": 1900},
    ]

    payload = {
        "username": "admin",
        "password": "password123",
        "telemetry": {
            "mouse_events": bot_mouse,
            "keyboard_events": bot_keyboard,
            "network_metadata": {"ip": "127.0.0.1"}
        }
    }

    print("\n[FinShield AI] 🚀 Sending automated 'Bot' login attempt...")
    try:
        res = requests.post("http://localhost:8000/auth/login", json=payload)
        print(f"[Result] Status Code: {res.status_code}")
        print(f"[Backend Response] {json.dumps(res.json(), indent=2)}")
        
        if res.status_code == 401:
            print("\n✅ SUCCESS: The Security Engine correctly detected the bot and blocked the attempt!")
        else:
            print("\n❌ FAILED: The engine did not detect the bot as high-risk.")
            
    except Exception as e:
        print(f"Error connecting to backend: {e}")

if __name__ == "__main__":
    run_test()
