import requests
import time
import json

# FinShield AI: Multi-Layered Attack Demo
# Demos: 1. Biometric Bot, 2. Network Anomaly, 3. DDoS Detection

def demo_attack():
    BASE_URL = "http://localhost:8000"
    
    print("\n--- 🛡️ FINSHIELD AI: MULTI-LAYER ATTACK DEMO ---")
    
    # 1. TEST BIOMETRIC BOT (Behavioral Layer)
    print("\n[Layer 1] Testing Biometric Bot Detection (Mechanical Input)...")
    payload_bot = {
        "username": "admin",
        "password": "password123",
        "telemetry": {
            "mouse_events": [{"x": i, "y": 100, "t": int(time.time()*1000) + i*10} for i in range(10)],
            "keyboard_events": [{"key": "m", "type": "keydown", "t": 1000}, {"key": "m", "type": "keyup", "t": 1100}],
            "network_metadata": {"ip": "10.0.0.1"}
        }
    }
    res = requests.post(f"{BASE_URL}/auth/login", json=payload_bot)
    print(f"Outcome: {res.status_code} (Expect 401)")
    
    # 2. VIEW LIVE SECURITY DASHBOARD DATA (Visibility Layer)
    print("\n[Layer 2] Fetching Real-time Security Stats...")
    stats = requests.get(f"{BASE_URL}/security/stats").json()
    print(f"System Stats: {json.dumps(stats, indent=2)}")
    
    print("\n--- ✅ DEMO COMPLETE ---")
    print("\nVisit http://localhost:8000/security/stats in your browser to see the live feed!")

if __name__ == "__main__":
    demo_attack()
