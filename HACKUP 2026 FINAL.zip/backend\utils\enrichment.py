import random

class IPEnricher:
    """
    Elite Enrichment: Flagging Datacenter IPs, VPNs, and Proxies.
    In a production app, this would use a GeoIP MaxMind DB or IP-API.
    """
    def __init__(self):
        # Mocking some known datacenter ASNs / IP types for demo
        self.DATACENTER_ORGS = ["AWS", "DigitalOcean", "Google Cloud", "Microsoft Azure", "Hetzner"]
        self.KNOWN_VPN_ASNS = [13679, 36351, 60068] # Example VPN Provider ASNs

    def get_metadata(self, ip):
        """Returns GeoIP and Org metadata for a given IP."""
        # Simulated logic for hackathon demo
        is_datacenter = any(org.lower() in ip.lower() for org in self.DATACENTER_ORGS) or ip.startswith("54.") or ip.startswith("3.")
        
        return {
            "ip": ip,
            "org": "Residential ISP" if not is_datacenter else random.choice(self.DATACENTER_ORGS),
            "is_datacenter": is_datacenter,
            "is_vpn": random.random() < 0.1, # 10% chance for dummy data
            "country": "IN",
            "city": "Mumbai",
            "lat": 19.0760,
            "lon": 72.8777
        }

    def calculate_velocity(self, session_id, current_geo):
        """
        'Impossible Travel' Detection:
        Compares current geo with previous session geo.
        """
        # Logic would store last known lat/lon and compare with current.
        # Returns True if travel speed > 1000 km/h
        return False
