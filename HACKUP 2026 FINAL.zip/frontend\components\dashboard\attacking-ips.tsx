'use client'

import { useState, useEffect, useCallback } from 'react'
import { AlertTriangle, Copy, Check, Globe, ShieldAlert, Activity } from 'lucide-react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

interface AttackingIP {
  ip: string
  country: string
  attempts: number
  severity: 'critical' | 'high' | 'medium'
  lastSeen: string
  reason: string
}

const REGIONS = ['Shanghai, China', 'Moscow, Russia', 'São Paulo, Brazil', 'Lagos, Nigeria', 'Hanoi, Vietnam', 'Kyiv, Ukraine', 'Tehran, Iran', 'Mumbai, India']

function hashIP(ip: string): number {
  let hash = 0
  for (let i = 0; i < ip.length; i++) hash = (hash * 31 + ip.charCodeAt(i)) & 0xfffffff
  return hash
}

function getSeverity(attempts: number): 'critical' | 'high' | 'medium' {
  if (attempts > 3000) return 'critical'
  if (attempts > 1500) return 'high'
  return 'medium'
}

function getSeverityColor(severity: string) {
  switch (severity) {
    case 'critical': return 'bg-red-600/10 border-red-500/30 text-red-700 shadow-red-500/5'
    case 'high': return 'bg-amber-600/10 border-amber-500/30 text-amber-700 shadow-amber-500/5'
    case 'medium': return 'bg-blue-600/10 border-blue-500/30 text-blue-700 shadow-blue-500/5'
    default: return 'bg-slate-100 border-slate-200 text-slate-700'
  }
}

interface AttackingIPsProps {
  filters?: { timeRange: string; riskLevel: string; status: string }
  isUnderAttack?: boolean
}

export default function AttackingIPs({ filters, isUnderAttack }: AttackingIPsProps) {
  const [ips, setIps] = useState<AttackingIP[]>([])
  const [copied, setCopied] = useState<string | null>(null)
  const [mounted, setMounted] = useState(false)

  const fetchBlocked = useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/api/v1/admin/database`)
      const data = await res.json()
      const records = (data.records || []).slice(0, 6)
      const mapped: AttackingIP[] = records.map((r: any) => {
        const h = hashIP(r.ip)
        const attempts = 500 + (h % 9500)
        return {
          ip: r.ip,
          country: REGIONS[h % REGIONS.length],
          attempts,
          severity: getSeverity(attempts),
          lastSeen: 'Just now',
          reason: r.reason || 'Unauthorized probe'
        }
      })
      setIps(mapped)
    } catch (e) {
      console.error('Failed to fetch attacking IPs', e)
    }
  }, [])

  useEffect(() => {
    setMounted(true)
    fetchBlocked()
    const interval = setInterval(fetchBlocked, 5000)
    window.addEventListener('refresh-dashboard', fetchBlocked)
    return () => {
      clearInterval(interval)
      window.removeEventListener('refresh-dashboard', fetchBlocked)
    }
  }, [fetchBlocked])

  const copyToClipboard = (ip: string) => {
    navigator.clipboard.writeText(ip)
    setCopied(ip)
    setTimeout(() => setCopied(null), 2000)
  }

  if (!mounted) return null

  return (
    <div className="bg-transparent space-y-8">
      <div className="flex items-center justify-between px-2">
        <div className="flex items-center gap-5">
          <div className="p-3 bg-red-600 rounded-2xl shadow-xl shadow-red-500/20">
            <ShieldAlert className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-black italic tracking-tighter uppercase text-slate-900 leading-none">Active_Threat_Signatures</h2>
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em] mt-1">{ips.length} Malicious Nodes Permanently Banned</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">Live Registry</span>
        </div>
      </div>

      {ips.length === 0 ? (
        <div className="py-20 text-center text-slate-400 font-black text-sm uppercase tracking-widest border-2 border-dashed border-slate-200 rounded-[3rem]">
          No threats logged yet — run a simulation to populate.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ips.map((ipData) => (
              <div className="flex flex-col h-full justify-between gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 min-w-0">
                      <Globe className="w-3.5 h-3.5 opacity-40 flex-shrink-0" />
                      <code className="text-sm font-mono font-black truncate tracking-tighter">{ipData.ip}</code>
                    </div>
                    <div className="flex items-center gap-2">
                       <div className="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border border-black/10 flex-shrink-0">
                        {ipData.severity}
                      </div>
                      <button
                        onClick={() => copyToClipboard(ipData.ip)}
                        className="p-2.5 bg-white/50 hover:bg-white rounded-xl transition-all shadow-sm flex-shrink-0"
                      >
                        {copied === ipData.ip ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-black uppercase tracking-widest opacity-40">Origin Node</span>
                      <span className="text-sm font-bold truncate leading-none uppercase italic tracking-tight">{ipData.country}</span>
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[9px] font-black uppercase tracking-widest opacity-40">Reason</span>
                      <span className="text-[10px] font-bold text-slate-600 leading-tight truncate">{ipData.reason}</span>
                    </div>
                  </div>
                </div>

                {/* 🛡️ BEAUTIFUL NUMBER BOX */}
                <div className="bg-slate-950 p-5 rounded-[1.8rem] border border-white/5 shadow-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-3 opacity-10"><Activity className="w-8 h-8 text-white" /></div>
                  <div className="flex items-center justify-between relative z-10">
                    <div className="flex flex-col">
                       <span className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] leading-none mb-2">Auth_Payload_Burst</span>
                       <span className="text-4xl font-black italic tracking-tighter leading-none text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.2)]">
                         {ipData.attempts.toLocaleString()}
                       </span>
                    </div>
                    <div className="flex flex-col items-end">
                       <span className={`text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-lg ${ipData.severity === 'critical' ? 'bg-red-600' : 'bg-blue-600'} text-white`}>
                         INTERDICTED
                       </span>
                    </div>
                  </div>
                </div>
              </div>
          ))}
        </div>
      )}
    </div>
  )
}
