'use client'

import React, { useState, useEffect, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Shield, ShieldAlert, Globe, Activity, AlertTriangle, Ban, CheckCircle2 } from 'lucide-react'
import { FilterState } from '@/app/page'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

interface ThreatEntry {
  id: string
  ip: string
  geo: string
  score: number
  classification: string
  subCategory: string
  action: 'ALLOWED' | 'BLOCKED' | 'MFA'
  time: string
}

const GEOS = ['Brazil', 'Russia', 'China', 'Germany', 'USA', 'India', 'Ukraine']
const CLASSIFICATIONS = ['Credential Stuffing', 'Bot Pattern', 'XSS Attempt', 'SQLi Probe', 'BOLA Attack', 'API Abuse']
const SUB_CATEGORIES = ['ACCOUNT TAKEOVER', 'DATA EXFILTRATION', 'SYSTEM BREACH', 'INFORMATION LEAK', 'API ENUMERATION']

function hashIP(ip: string): number {
  let hash = 0
  for (let i = 0; i < ip.length; i++) hash = (hash * 31 + ip.charCodeAt(i)) & 0xfffffff
  return hash
}

function convertToIST(isoString: string): string {
  try {
    const normalized = isoString.includes('Z') || isoString.includes('+') ? isoString : isoString + 'Z'
    return new Date(normalized).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit' })
  } catch { return isoString }
}

export default function ThreatFeed({ filters, isUnderAttack }: { filters: FilterState, isUnderAttack: boolean }) {
  const [entries, setEntries] = useState<ThreatEntry[]>([])

  const fetchThreats = async () => {
    try {
      const res = await fetch(`${API_URL}/api/v1/admin/database`)
      const data = await res.json()
      const records = data.records || []
      const mapped: ThreatEntry[] = records.map((r: any) => {
        const h = hashIP(r.ip)
        return {
          id: String(r.id),
          ip: r.ip,
          geo: GEOS[h % GEOS.length],
          score: parseFloat((0.5 + (h % 50) / 100).toFixed(2)),
          classification: CLASSIFICATIONS[h % CLASSIFICATIONS.length],
          subCategory: SUB_CATEGORIES[h % SUB_CATEGORIES.length],
          action: 'BLOCKED' as const,
          time: convertToIST(r.time)
        }
      })
      setEntries(mapped)
    } catch (e) {
      console.error('Failed to fetch threat feed', e)
    }
  }

  useEffect(() => {
    fetchThreats()
    const interval = setInterval(fetchThreats, 5000)
    window.addEventListener('refresh-dashboard', fetchThreats)
    return () => {
      clearInterval(interval)
      window.removeEventListener('refresh-dashboard', fetchThreats)
    }
  }, [])

  useEffect(() => {
    if (isUnderAttack) {
      const spoofIPs = ['91.108.4.1', '185.220.101.5', '45.155.205.10', '103.14.12.98']
      const newEntry: ThreatEntry = {
        id: Date.now().toString(),
        ip: spoofIPs[Math.floor(Math.random() * spoofIPs.length)],
        geo: GEOS[Math.floor(Math.random() * GEOS.length)],
        score: parseFloat((0.85 + Math.random() * 0.14).toFixed(2)),
        classification: 'Bot Pattern',
        subCategory: 'RDoS_INJECTION',
        action: 'BLOCKED',
        time: new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })
      }
      setEntries(prev => [newEntry, ...prev.slice(0, 20)])
    }
  }, [isUnderAttack])

  const filteredEntries = useMemo(() => {
    return entries.filter(e => {
      if (filters.status !== 'All' && e.action !== filters.status.toUpperCase()) return false
      if (filters.riskLevel !== 'All Levels') {
        if (filters.riskLevel === 'High' && e.score < 0.7) return false
        if (filters.riskLevel === 'Medium' && (e.score < 0.4 || e.score > 0.7)) return false
      }
      return true
    })
  }, [entries, filters])

  return (
    <Card className="relative overflow-hidden border-none shadow-3xl bg-white dark:bg-slate-900/40 rounded-[3rem] transition-all duration-1000">
      <CardHeader className="px-10 py-10">
        <CardTitle className="text-2xl font-black italic tracking-tighter uppercase text-slate-800 dark:text-white">
          Live Defensive Actions Feed
          <span className="ml-4 text-[11px] font-black text-emerald-500 uppercase tracking-widest not-italic">● LIVE</span>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="px-0 pb-12">
        <ScrollArea className="h-[600px] w-full px-10">
          <div className="w-full min-w-[800px]">
             <div className="grid grid-cols-12 gap-4 pb-6 px-4 border-b border-slate-100 dark:border-white/5 opacity-40">
                <span className="col-span-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Source/Geo (IST)</span>
                <span className="col-span-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 text-center">Score</span>
                <span className="col-span-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Classification</span>
                <span className="col-span-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 text-right pr-4">Action</span>
             </div>

             <div className="space-y-4 pt-6">
                {filteredEntries.length === 0 ? (
                  <div className="py-16 text-center text-slate-400 font-black text-sm uppercase tracking-widest">
                    No threats logged yet. Run a simulation.
                  </div>
                ) : filteredEntries.map((entry) => (
                    <div key={entry.id} className="grid grid-cols-12 gap-4 items-center px-4 py-4 rounded-[2rem] hover:bg-slate-50 dark:hover:bg-slate-950/40 transition-all group">
                        
                        <div className="col-span-4 flex flex-col justify-center">
                            <span className="text-[15px] font-black text-slate-900 dark:text-white tracking-tight leading-none mb-1">{entry.ip}</span>
                            <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest leading-none">
                                {entry.geo} <span className="opacity-40 font-mono ml-2">· {entry.time}</span>
                            </span>
                        </div>

                        <div className="col-span-2 flex justify-center">
                            <span className={`text-[16px] font-black transition-all ${
                                entry.score > 0.7 ? 'text-red-500' : entry.score > 0.5 ? 'text-amber-500' : 'text-emerald-500'
                            }`}>
                                {entry.score.toFixed(2)}
                            </span>
                        </div>

                        <div className="col-span-4 flex flex-col justify-center">
                            <span className="text-[13px] font-black text-slate-700 dark:text-slate-300 tracking-tight leading-none mb-1">{entry.classification}</span>
                            <span className="text-[10px] font-black text-red-500/80 uppercase tracking-tighter leading-none italic">
                                → {entry.subCategory}
                            </span>
                        </div>

                        <div className="col-span-2 flex justify-end pr-4">
                            <div className={`px-4 py-1.5 rounded-full border-2 text-[10px] font-black tracking-widest uppercase transition-all shadow-sm ${
                                entry.action === 'BLOCKED' ? 'bg-red-500/10 border-red-500 text-red-500' : 
                                entry.action === 'ALLOWED' ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' : 
                                'bg-amber-500/10 border-amber-500 text-amber-500'
                            }`}>
                                {entry.action}
                            </div>
                        </div>

                    </div>
                ))}
             </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
