import requests
import time
import random
import json

BASE_URL = "http://localhost:8000"

def simulate_behavioral_bot(headers):
    print("--- Simulating Scripted Bot (Mechanical Biometrics) ---")
    payload = {
        "username": "bot_user",
        "password": "password123",
        "telemetry": {
            "mouse_events": [{"x": i, "y": i, "t": time.time() + i*0.01} for i in range(100)], # Perfectly straight line
            "keyboard_events": [{"key": "a", "type": "keydown", "t": i*100} for i in range(10)], # Constant rhythm
            "network_metadata": {"ip": "54.1.2.3", "ua": "Python-Requests"} # Datacenter IP
        }
    }
    r = requests.post(f"{BASE_URL}/auth/login", json=payload, headers=headers)
    print(f"Response: {r.status_code} - {r.json()}")

def simulate_honeypot_hit(headers):
    print("\n--- Simulating Automated Scanner (Seceon-Grade Honeypot) ---")
    # Testing the new Seceon-specified path
    r = requests.get(f"{BASE_URL}/api/v1/admin/hidden-auth", headers=headers)
    print(f"Response (Honeypot Hit): {r.status_code} - {r.text}")
    
    # Testing Global Shield Middleware (Should be blocked now)
    print("\n--- Verifying Global Shield (Middleware Block) ---")
    r2 = requests.get(f"{BASE_URL}/", headers=headers)
    print(f"Response (Subsequent Request): {r2.status_code} - {r2.text}")

def simulate_status_check(headers):
    print("\n--- Checking IP Status (Fast Polling) ---")
    r = requests.get(f"{BASE_URL}/api/status", headers=headers)
    print(f"Response: {r.status_code} - {r.json()}")


def simulate_bulk_telemetry(headers):
    print("\n--- Simulating High-Frequency Bulk Telemetry Stream ---")
    payload = {
        "session_id": "session_abc_123",
        "events": [
            {"type": "mouse", "data": {"x": random.randint(0,100), "y": random.randint(0,100)}, "timestamp": time.time()},
            {"type": "keyboard", "data": {"key": "enter", "type": "keydown"}, "timestamp": time.time()}
        ]
    }
    r = requests.post(f"{BASE_URL}/api/telemetry", json=payload, headers=headers)
    print(f"Response: {r.status_code} - {r.json()}")

if __name__ == "__main__":
    spoofed_ip = f"{random.randint(11, 250)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}"
    print(f"🚀 Starting FinShield AI ELITE SOC Simulator")
    print(f"👺 Spoofing Attacker IP as: {spoofed_ip}")
    
    headers = {"X-Forwarded-For": spoofed_ip}
    try:
        simulate_status_check(headers)
        simulate_bulk_telemetry(headers)
        time.sleep(1)
        simulate_behavioral_bot(headers)
        time.sleep(1)
        simulate_honeypot_hit(headers)
        time.sleep(1)
        simulate_status_check(headers)

    except Exception as e:
        print(f"❌ Simulator failed: {e}. Is the backend running?")
