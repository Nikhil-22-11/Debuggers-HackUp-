class RiskEngine:
    """
    Elite Level Risk Scoring Engine.
    Aggregates indicators from Behavioral, Network, and Session layers.
    """
    def __init__(self):
        # Weights as per the 'Elite Level' Problem Statement
        self.WEIGHTS = {
            "behavioral": 0.40,
            "network": 0.35,
            "session": 0.25
        }

    def calculate_total_score(self, behavioral_score, network_score, session_score):
        """
        Calculates the dynamic risk score (0.0 to 1.0) and analysis reasons.
        """
        total = (
            (behavioral_score * self.WEIGHTS["behavioral"]) +
            (network_score * self.WEIGHTS["network"]) +
            (session_score * self.WEIGHTS["session"])
        )
        
        # 1. Explainable Threat Analysis Logic
        analysis = []
        if behavioral_score > 0.8: analysis.append("Superhuman mouse movement or typing cadence detected.")
        elif behavioral_score > 0.5: analysis.append("Suspicious interaction pattern flagged as non-human.")
        
        if network_score > 0.8: analysis.append("Originating from a high-risk datacenter, VPN, or Proxy.")
        elif network_score > 0.5: analysis.append("Anomalous network metadata detected.")
        
        if session_score > 0.8: analysis.append("Impossible travel velocity or session replay detected.")
        
        return float(min(total, 1.0)), analysis

    def get_risk_level(self, score):

        """Returns human-readable risk category."""
        if score > 0.85:
            return "CRITICAL"
        elif score > 0.60:
            return "HIGH"
        elif score > 0.30:
            return "MEDIUM"
        return "LOW"
