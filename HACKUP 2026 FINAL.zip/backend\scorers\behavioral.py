import numpy as np
import pickle
from core.config import MODELS_DIR

class BehavioralScorer:
    """
    Elite-level behavioral biometric scorer.
    Differentiates between human-like 'imperfect' movement and bot-like 'mathematical' movement.
    """
    def __init__(self):
        # Thresholds tuned from common behavioral biometric benchmarks
        self.MIN_HUMAN_JITTER = 0.05  
        self.MAX_HUMAN_EFFICIENCY = 0.98  
        self.MIN_DWELL_TIME_VAR = 5.0  
        self.model_path = str(MODELS_DIR / "keystroke_model.pkl")
        self.model = None
        self.feature_names = []
        self._load_model()

    def _load_model(self):
        try:
            with open(self.model_path, "rb") as f:
                self.model = pickle.load(f)
                self.feature_names = pickle.load(f)
                print(f"✅ Loaded Keystroke Model from {self.model_path}")
        except:
            print(f"⚠️ Keystroke model not found. Using heuristic fallback.")


    def score_mouse_movement(self, events):
        """
        Input: list of {x, y, t} events
        Returns: 0.0 (Human) to 1.0 (Bot)
        """
        if len(events) < 10:
            return 0.5 # Not enough data
        
        coords = np.array([[e.get('x', 0), e.get('y', 0)] for e in events])
        times = np.array([e.get('t', 0) for e in events])
        
        # 1. Path Efficiency (Curvature)
        # Bots move in Euclidean straight lines. Humans have motor noise (curvature).
        diffs = np.diff(coords, axis=0)
        total_dist = np.sum(np.sqrt(np.sum(diffs**2, axis=1)))
        direct_dist = np.sqrt(np.sum((coords[-1] - coords[0])**2))
        efficiency = direct_dist / total_dist if total_dist > 0 else 1.0
        
        # 2. Velocity Jitter (Sudden jumps vs smooth acceleration)
        dt = np.diff(times)
        valid_dt = dt[dt > 0]
        if len(valid_dt) < 5: return 0.5
        
        dists = np.sqrt(np.sum(diffs**2, axis=1))
        # Velocities: distance / time_delta
        velocities = dists[dt > 0] / valid_dt
        
        # Jitter: Standard deviation of velocity relative to mean
        v_mean = np.mean(velocities)
        jitter = np.std(velocities) / (v_mean + 1e-6)
        
        bot_score = 0.0
        if efficiency > 0.99: # Almost perfectly straight
            bot_score += 0.5
        if jitter < 0.02: # Extremely constant speed (scripted)
            bot_score += 0.5
            
        return float(min(bot_score, 1.0))


    def score_keystrokes(self, events):
        """
        Calculates keystroke score using model inference or elite heuristics.
        """
        if len(events) < 5: return 0.5
        
        # 1. Feature Extraction (matching the DSL dataset structure)
        # The DSL dataset uses Dwell Times (H.key) and Interval Times (UD.key.key)
        # For demo simplicity, we extract mean/std of dwell times.
        dwell_times = []
        presses = {}
        for e in events:
            if e['type'] == 'keydown': presses[e['key']] = e['t']
            elif e['type'] == 'keyup' and e['key'] in presses:
                dwell_times.append(e['t'] - presses[e['key']])
        
        if not dwell_times: return 0.5
        
        # 2. Model Inference
        if self.model:
            # We must map our extracted session features to the 31 columns expected by the RFC
            # Here we simulate the vector by padding the mean dwell time
            mean_dwell = sum(dwell_times) / len(dwell_times)
            vector = [mean_dwell] * len(self.feature_names)
            return float(self.model.predict_proba([vector])[0][1])

        # 3. Elite Heuristic Fallback
        dwell_var = np.var(dwell_times)
        if dwell_var < self.MIN_DWELL_TIME_VAR: return 0.9
        return 0.1

