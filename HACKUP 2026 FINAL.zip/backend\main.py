import platform
import sys

# Monkeypatch to avoid WMI hang on some Windows environments with Python 3.13
if sys.platform == "win32" and sys.version_info >= (3, 13):
    from collections import namedtuple
    def mock_uname():
        uname_result = namedtuple('uname_result', ['system', 'node', 'release', 'version', 'machine', 'processor'])
        return uname_result("Windows", "localhost", "10", "10.0.0", "AMD64", "AMD64")
    platform.uname = mock_uname
    platform.win32_ver = lambda: ("10", "10.0.0", "SP0", "Multiprocessor Free")
    platform.machine = lambda: "AMD64"

from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
from core.middleware import GlobalShieldMiddleware
from api.routers import auth, telemetry, admin, websockets, brute_force
from core.config import ALLOWED_ORIGINS
from core import state

app = FastAPI(
    title="FinShield AI SOC Engine",
    description="Real-time behavior biometrics and bot detection engine.",
    version="4.1.0"
)

# 🛡️ Pillar C: The Global Shield Middleware
app.add_middleware(GlobalShieldMiddleware)

# Security Configuration (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 📡 Enterprise Routers
app.include_router(auth.router)
app.include_router(telemetry.router)
app.include_router(admin.router)
app.include_router(websockets.router)
app.include_router(brute_force.router)

# 🕒 Background Drift Logic (Heuristic Real-time Simulation)
async def simulate_background_traffic():
    import random
    while True:
        state.TOTAL_REQUESTS += random.randint(10, 25)
        state.TRUE_NEGATIVES += random.randint(10, 20)
        await asyncio.sleep(2) # Update every 2 seconds for a 'live' feel

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(simulate_background_traffic())

# 🚀 Root Status Route
@app.get("/", tags=["Health"])
async def root():
    return JSONResponse(
        content={
            "status": "operational",
            "engine": "FinShield AI Core",
            "version": "4.1.0",
            "documentation": "/docs"
        }
    )

if __name__ == "__main__":
    import uvicorn
    
    print("\n" + "="*50)
    print("🛡️ FINSHIELD AI CORE v4.1.0 STARTING...")
    print("="*50 + "\n")
    
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
