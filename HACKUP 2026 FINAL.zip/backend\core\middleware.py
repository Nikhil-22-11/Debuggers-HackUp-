from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse
from fastapi import Request
from db.database import SessionLocal, BlockedIP

def json_response(content: dict, status_code: int):
    return JSONResponse(content=content, status_code=status_code)

class GlobalShieldMiddleware(BaseHTTPMiddleware):
    """
    Pillar C: The Middleware Shield.
    Intercepts EVERY request and blocks if IP exists in global_threat_registry (Database).
    """
    async def dispatch(self, request: Request, call_next):
        # Whitelist dashboard, Swagger docs, and admin routes so they are never blocked
        SAFE_PATHS = [
            "/api/v1/admin/database", "/security/stats", "/api/status", "/ws/alerts",
            "/api/v1/admin/hidden-auth", "/docs", "/redoc", "/openapi.json",
        ]
        # Robust whitelist check
        path = request.url.path.rstrip("/")
        if any(path.endswith(p.rstrip("/")) for p in SAFE_PATHS) or path.startswith("/docs"):
            return await call_next(request)

        client_ip = request.headers.get("X-Forwarded-For", request.client.host).split(",")[0].strip()
        
        # NEVER block localhost to prevent lockout during development
        if client_ip in ["127.0.0.1", "::1"]:
            return await call_next(request)

        db = SessionLocal()
        is_blocked = db.query(BlockedIP).filter(BlockedIP.ip_address == client_ip).first()
        db.close()
        
        if request.method == "OPTIONS":
            return await call_next(request)

        if is_blocked:
            # TERMINAL LOGGING FOR MENTORSHIP
            print(f"[🛑 BLOCK EVENT] Dropped request from {client_ip} (Known Threat)")
            
            return JSONResponse(
                content={"status": "BLOCKED", "message": "Threat Neutralized by FinShield AI Shield."},
                status_code=403,
                headers={
                    "Access-Control-Allow-Origin": "http://localhost:3000",
                    "Access-Control-Allow-Credentials": "true",
                    "Access-Control-Allow-Methods": "*",
                    "Access-Control-Allow-Headers": "*",
                }
            )
        return await call_next(request)
