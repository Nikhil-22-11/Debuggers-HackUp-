from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime
from core.config import DATABASE_URL

SQLALCHEMY_DATABASE_URL = DATABASE_URL

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class BlockedIP(Base):
    __tablename__ = "blocked_ips"

    id = Column(Integer, primary_key=True, index=True)
    ip_address = Column(String, unique=True, index=True)
    reason = Column(String)
    blocked_at = Column(DateTime, default=datetime.utcnow)

class SecurityAlert(Base):
    __tablename__ = "security_alerts"

    id = Column(Integer, primary_key=True, index=True)
    alert_type = Column(String, index=True)
    ip_address = Column(String, index=True)
    score = Column(Float)
    action = Column(String)
    analysis = Column(String)  # Stored as JSON string
    created_at = Column(DateTime, default=datetime.utcnow)

class BruteForceAttempt(Base):
    """Logs every failed login attempt with the email and masked password used."""
    __tablename__ = "brute_force_attempts"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, index=True)
    password_mask = Column(String)        # e.g. "pass****" - never store plaintext
    ip_address = Column(String, index=True)
    attempt_number = Column(Integer)      # 1, 2, or 3
    session_id = Column(String, index=True)   # Groups attempts by session
    attempted_at = Column(DateTime, default=datetime.utcnow)

class AccountLockout(Base):
    """Tracks active lockouts keyed by email. Persists across page refreshes."""
    __tablename__ = "account_lockouts"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    ip_address = Column(String)
    locked_at = Column(DateTime, default=datetime.utcnow)
    unlocks_at = Column(DateTime)         # locked_at + 60 seconds
    is_active = Column(Boolean, default=True)
    total_attempts = Column(Integer, default=3)

class CaptchaLog(Base):
    """Tracks CAPTCHA challenges generated for suspicious logins. Default status is BOT, becomes HUMAN if solved."""
    __tablename__ = "captcha_logs"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, index=True)
    password_mask = Column(String)
    captcha_code = Column(String)
    status = Column(String, default="BOT")  # BOT or HUMAN
    created_at = Column(DateTime, default=datetime.utcnow)

class CaptchaVerified(Base):
    """SEPARATE DATABASE: Stores only successfully verified human identities."""
    __tablename__ = "captcha_verified"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, index=True)
    password_mask = Column(String)
    captcha_code = Column(String)
    status = Column(String, default="HUMAN")
    verified_at = Column(DateTime, default=datetime.utcnow)

# Create tables if they don't exist
Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
