from typing import List
from fastapi import WebSocket

# In-memory Application State
WEBSOCKETS: List[WebSocket] = []
TOTAL_REQUESTS = 0
ANOMALY_SESSIONS = 0

# ML Performance Counters (Ultra-reduced for demo 'fluctuation')
TRUE_POSITIVES = 42
TRUE_NEGATIVES = 124
FALSE_POSITIVES = 2
FALSE_NEGATIVES = 1

# Elite Session State
SESSIONS = {}
